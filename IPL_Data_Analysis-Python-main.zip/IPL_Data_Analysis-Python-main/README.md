• Analysed Data using Pandas, Numpy,and Seaborn library.

• Analysed each team's stats of IPL to get insight of which team is more successful.

• Analysed Each Player's stats to get insight of the Most run-scored Batsmen, the Most wicket-taking bowler, and the player who got the most MOM.

• Analysed toss stats to check whether toss plays a major role in winning a match.
